package com.example.expandlistview;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;

import androidx.annotation.Nullable;

import java.io.IOException;

public class MusicService extends Service {

    private final IBinder binder = new MyBinder();


    public class MyBinder extends Binder {
        public MusicService getService() {
            return MusicService.this;    //返回本服务
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    MediaPlayer mp;

    public MusicService() {
    }

    @Override
    public void onCreate() {
        mp = new MediaPlayer();
    }

    @Override
    public void onDestroy() {


    }




    @SuppressLint("WrongConstant")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String cmd = intent.getStringExtra("cmd");
        if (cmd != null){
            if (cmd.equals("play")){
                mp.start();
                System.out.println("开始播放");
            }
            else if (cmd.equals("pause")){
                pause();
                System.out.println("暂停播放");
            }
            else if (cmd.equals("stop")){
                stop();
                System.out.println("停止播放");
            }
        }
        return 0;
    }

    public void play(String path){
        System.out.println(path);

        mp.reset();
        try {
            mp.setDataSource(path);
            mp.prepare();
            mp.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void stop(){
        mp.stop();
    }

    public void pause(){
        mp.pause();
    }
    public void resume(){
        mp.start();
    }
    public int getMusicCurTime(){
        return mp.getCurrentPosition();
    }

    public int getMusicTotalTime(){
        return mp.getDuration();
    }
    public void seekTo(int time){
        mp.seekTo(time);
    }

}
