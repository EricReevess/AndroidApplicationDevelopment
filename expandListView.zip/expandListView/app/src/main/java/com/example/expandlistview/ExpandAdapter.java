package com.example.expandlistview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ExpandAdapter extends BaseExpandableListAdapter {

    private String [] groupName ;
    private String [][] childName;
    private int [] groupPic;
    private int [] [] childPic;

    LayoutInflater layoutInflater;

    public ExpandAdapter(Context context, String[] groupName, String[][] childName, int[] groupPic, int[][] childPic) {
        this.layoutInflater = LayoutInflater.from(context);
        this.groupName = groupName;
        this.childName = childName;
        this.groupPic = groupPic;
        this.childPic = childPic;

    }

    @Override
    public int getGroupCount() {
        return groupName.length;
    }

    @Override
    public int getChildrenCount(int i) {
        return childName[i].length;
    }

    @Override
    public Object getGroup(int i) {
        return groupName[i];
    }

    @Override
    public Object getChild(int i, int i1) {
        return childName[i][i1];
    }

    @Override
    public long getGroupId(int i) {
        return i;
    }

    @Override
    public long getChildId(int i, int i1) {
        return i1;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int i, boolean b, View view, ViewGroup viewGroup) {
        view = layoutInflater.inflate(R.layout.group_layout , null);
        TextView textView = view.findViewById(R.id.textView);
        textView.setText(getGroup(i).toString());
        ImageView imageView = view.findViewById(R.id.imageView);
        imageView.setImageResource(groupPic[i]);
        return view;
    }

    @Override
    public View getChildView(int i, int i1, boolean b, View view, ViewGroup viewGroup) {
        view = layoutInflater.inflate(R.layout.child_layout , null);
        TextView childTextView = view.findViewById(R.id.textView);
        childTextView.setText(getChild(i,i1).toString());
        ImageView childImageView = view.findViewById(R.id.imageView);
        childImageView.setImageResource(childPic[i][i1]);
        return view;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }
}
