package com.example.expandlistview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ExpandableListView expandableListView;
    private ExpandAdapter expandAdapter;

    private String [] groupName = new String[]{"朋友","亲人","同学"};

    private int [] groupPic = new int[]{R.drawable.friends , R.drawable.family , R.drawable.classmate};

    private String [] [] childName = new String[][]{{"朋友1","朋友2"},{"亲人1","亲人2"},{"同学1","同学2"}};

    private int [] [] childPic = new int[][]{{R.drawable.boy,R.drawable.girl},
            {R.drawable.girl2,R.drawable.boy},
            {R.drawable.girl,R.drawable.girl2}};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        expandableListView = findViewById(R.id.expListView01);
        expandAdapter = new ExpandAdapter(this , groupName , childName , groupPic , childPic );
        expandableListView.setAdapter(expandAdapter);

        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView expandableListView, View view, int i, int i1, long l) {
                Toast.makeText(getApplicationContext() , groupName[i]+":"+childName[i][i1],Toast.LENGTH_SHORT).show();
                return false;
            }
        });
    }
}
