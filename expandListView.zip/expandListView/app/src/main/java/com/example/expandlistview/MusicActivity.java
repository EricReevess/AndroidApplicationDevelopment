package com.example.expandlistview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.ThemedSpinnerAdapter;

public class MusicActivity extends AppCompatActivity {

    private MusicService musicService;
    //绑定Service监听
    ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceDisconnected(ComponentName name) {
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            musicService = ((MusicService.MyBinder) service).getService();

        }
    };

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            seekBar.setProgress(msg.arg1);
        }
    };


    ListView listView;
    ArrayAdapter<String> songListAdapter;
    Button playBtn;
    Button stopBtn;
    SeekBar seekBar;
    private int percentage = 0;
    boolean isPlay = false;
    boolean isUserCtrlSeekBar = false;
    boolean isThreadRunning;
    private int totalTime;
    private int currentTime;

    @Override
    protected  void onDestroy() {
        super.onDestroy();
        isThreadRunning = false;
        unbindService((ServiceConnection) musicService);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        final Thread[] thread = new Thread[1];

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);

        listView = findViewById(R.id.listView01);
        playBtn = findViewById(R.id.playBtn);
        stopBtn = findViewById(R.id.stopBtn);
        seekBar = findViewById(R.id.seekBar);

        songListAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
        songListAdapter.add("/sdcard/Music/music1.mp3");
        songListAdapter.add("/sdcard/Music/music2.mp3");

        isThreadRunning = thread[0].isAlive();
        listView.setAdapter(songListAdapter);

        final Intent musicBind = new Intent(MusicActivity.this, MusicService.class);
        bindService(musicBind, serviceConnection, Context.BIND_AUTO_CREATE);

        playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(getBaseContext(), MusicService.class);
                if (!isPlay) {
                    //it.putExtra("cmd", "play");
                    musicService.resume();
                    playBtn.setText("pause");
                    isPlay = true;
                } else {
                    it.putExtra("cmd", "pause");
                    playBtn.setText("play");
                    isPlay = false;
                }
                startService(it);
            }
        });


        stopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(getBaseContext(), MusicService.class);
                it.putExtra("cmd", "stop");
                startService(it);
            }
        });


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isUserCtrlSeekBar = true;
                musicService.pause();
                playBtn.setText("play");
                isPlay = false;

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                isUserCtrlSeekBar = false;
                musicService.seekTo(seekBar.getProgress());
                musicService.resume();
                playBtn.setText("pause");
                isPlay = true;
            }
        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                musicService.play(songListAdapter.getItem(i));
                seekBar.setMax(musicService.getMusicTotalTime());

                playBtn.setText("pause");
                isPlay = true;

                thread[0] = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        totalTime = musicService.getMusicTotalTime();

                        while (currentTime <= totalTime) {

                            if (musicService != null && !isUserCtrlSeekBar ) {
                                currentTime = musicService.getMusicCurTime();

                                Message message = handler.obtainMessage();
                                message.arg1 = currentTime;
                                handler.sendMessage(message);

                                try {
                                    Thread.sleep(100);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }

                        }
                    }
                });

                thread[0].start();
            }
        });


    }


}
