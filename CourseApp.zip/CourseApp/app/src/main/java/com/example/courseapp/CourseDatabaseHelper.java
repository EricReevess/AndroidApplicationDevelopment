package com.example.courseapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class CourseDatabaseHelper extends SQLiteOpenHelper {


    private final String CREATE_SQL = "create table if not exists Course(_id integer primary key, " +
            "course_no varchar, " +
            "course_name varchar," +
            "credit integer, " +
            "remark varchar  )";

    public CourseDatabaseHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_SQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insert(String[] courseData) {
        this.getWritableDatabase().execSQL("insert into Course Values(null , ?, ?, ?, ?)", courseData);
    }
    public Cursor queryInName (String name){
        return this.getReadableDatabase().rawQuery("select * from Course Where course_name like ?" , new String[]{"%" + name+ "%"});
    }
}
