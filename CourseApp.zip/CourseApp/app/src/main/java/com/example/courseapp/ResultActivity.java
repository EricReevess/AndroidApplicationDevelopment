package com.example.courseapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.List;
import java.util.Map;

public class ResultActivity extends AppCompatActivity {


    ListView listView;
    ArrayAdapter<String> ListAdapter;
    private Button btn_close;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);


        listView = findViewById(R.id.listView_result);
        btn_close = findViewById(R.id.button_close);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        List<Map<String, String>> list = (List<Map<String, String>>) bundle.getSerializable("data");

        if (list.size() == 0) {
            this.setTitle("无结果:");
        } else {
            this.setTitle("找到以下结果：");
            SimpleAdapter simpleAdapter = new SimpleAdapter(ResultActivity.this,
                    list,
                    R.layout.child_layout,
                    new String[]{"course_no", "course_name", "credit", "remark"},
                    new int[]{R.id.textView11, R.id.textView22, R.id.textView33, R.id.textView44,});
            listView.setAdapter(simpleAdapter);
        }

        btn_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
}
