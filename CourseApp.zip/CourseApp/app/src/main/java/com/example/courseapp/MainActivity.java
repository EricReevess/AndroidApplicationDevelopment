package com.example.courseapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private CourseDatabaseHelper courseDatabaseHelper;
    private Button btn_add;
    private Button btn_search;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        courseDatabaseHelper = new CourseDatabaseHelper(this, "StudentSystem", null, 1);
        btn_add = findViewById(R.id.button);
        btn_search = findViewById(R.id.button2);

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Course_no = ((EditText) findViewById(R.id.editText1)).getText().toString();
                String course_name = ((EditText) findViewById(R.id.editText2)).getText().toString();
                String credit = ((EditText) findViewById(R.id.editText3)).getText().toString();
                String remark = ((EditText) findViewById(R.id.editText4)).getText().toString();

                insertData(courseDatabaseHelper.getReadableDatabase(), Course_no, course_name, credit, remark);

                Toast.makeText(getApplicationContext(), "添加成功", Toast.LENGTH_SHORT).show();

                ((EditText) findViewById(R.id.editText1)).setText("");
                ((EditText) findViewById(R.id.editText2)).setText("");
                ((EditText) findViewById(R.id.editText3)).setText("");
                ((EditText) findViewById(R.id.editText4)).setText("");
            }
        });
        btn_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String courseName = ((EditText) findViewById(R.id.editText5)).getText().toString();
                Cursor cursor = courseDatabaseHelper.queryInName(courseName);
                Bundle bundle = new Bundle();
                bundle.putSerializable("data",CursorToList(cursor));
                System.out.println(bundle.getSerializable("data"));
                Intent intent = new Intent(MainActivity.this , ResultActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }

    private void insertData(SQLiteDatabase sqLiteDatabase, String Course_no, String course_name, String credit, String remark) {
        this.courseDatabaseHelper.insert(new String[]{Course_no, course_name, credit, remark});
    }

    private void getData() {

    }


    private ArrayList<Map<String, String>> CursorToList(Cursor cursor) {
        ArrayList<Map<String, String>> result = new ArrayList<>();
        while (cursor.moveToNext()) {
            Map<String, String> map = new HashMap<>();
            map.put("course_no", cursor.getString(1));
            map.put("course_name", cursor.getString(2));
            map.put("credit", cursor.getString(3));
            map.put("remark", cursor.getString(4));
            result.add(map);
        }
        return result;
    }
}
