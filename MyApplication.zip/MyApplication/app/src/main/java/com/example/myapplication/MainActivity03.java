package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity03 extends AppCompatActivity {

    private ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listview01);

        listView = findViewById(R.id.listView01);

        final String [] names = new String[]{"Steam" , "Origin" , "Windows" ,"macOS"};
        final String [] details = new String[]{"英语学习平台1" , "英语学习平台2" , "很多人用的系统" ,"很贵的系统"};
        final int[] icon = new int[] {R.drawable.steam ,
                                        R.drawable.origin ,
                                        R.drawable.windows,
                                        R.drawable.macos
        };
        List list = new ArrayList();
        for (int i = 0 ; i<names.length; i++){
            Map<String,Object> items = new HashMap<>();
            items.put("names" , names[i]);
            items.put("details" , details[i]);
            items.put("icon" , icon[i]);
            list.add(items);
        }

        SimpleAdapter simpleAdapter = new SimpleAdapter(this , list ,  R.layout.text_item ,
                new String[]{"names" , "details" , "icon"} ,
                new int[]{R.id.textView , R.id.textView2 ,R.id.imageView });

        listView.setAdapter(simpleAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(getApplicationContext() , names[i] , Toast.LENGTH_SHORT).show();
            }
        });

    }
}
