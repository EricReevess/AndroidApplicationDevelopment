package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.os.Handler;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    EditText ed_username;
    EditText ed_password;

    RadioGroup rg_sex;

    CheckBox cb_hobby1;
    CheckBox cb_hobby2;
    CheckBox cb_hobby3;

    Button button;


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            if (resultCode == 1){
                ed_username.setText(data.getStringExtra("sex"));
            }
        }
    }

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_linerlayout);

        ed_username = findViewById(R.id.editText1);
        ed_password = findViewById(R.id.editText2);
        rg_sex = findViewById(R.id.radioGroup);
        cb_hobby1 = findViewById(R.id.checkBox);
        cb_hobby2 = findViewById(R.id.checkBox2);
        cb_hobby3 = findViewById(R.id.checkBox3);
        button = findViewById(R.id.button1);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String username = ed_username.getText().toString();
                String password = ed_password.getText().toString();

                String sex = "";
                ArrayList<String> hobby = new ArrayList<String>();
                int s = rg_sex.getCheckedRadioButtonId();
                if(s == R.id.radioButton){
                    sex = "男";
                }else if (s == R.id.radioButton2){
                    sex = "女";
                }

                if (cb_hobby1.isChecked()){
                    hobby.add(cb_hobby1.getText().toString());
                }
                if (cb_hobby2.isChecked()){
                    hobby.add(cb_hobby2.getText().toString());
                }
                if (cb_hobby3.isChecked()){
                    hobby.add(cb_hobby3.getText().toString());
                }

                Intent intent = new Intent(MainActivity.this , MainActivity02.class);
                Bundle bundle = new Bundle();
                bundle.putString("username" ,ed_username.getText().toString() );
                bundle.putString("password" ,ed_password.getText().toString() );
                bundle.putString("sex" , sex);
                bundle.putString("hobby",hobby.toString());
                intent.putExtras(bundle);
                startActivityForResult(intent,1);
                Log.i("info" , "用户名：" + username  + ",密码：" + password + ",性别：" + sex + ",爱好：" + hobby.toString() );
            }
        });
    }

    /*@Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart()被调用，Activity进入可见状态");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume()被调用，Activity进入运行 状态 并且可以 获取焦点");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause()被调用，Activity进入可见但不可操作状态（失去焦点）");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop()被调用，Activity进入不可见的停止状态");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart()被调用，Activity进入重启状态，即将调用onStart() 以及 onResume() ");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy()被调用，Activity即将被销毁");
    }*/
}
