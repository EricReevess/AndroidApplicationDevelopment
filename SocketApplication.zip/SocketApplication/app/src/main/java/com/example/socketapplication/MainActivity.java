package com.example.socketapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private SocketService socketService;
    //绑定Service监听
    ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceDisconnected(ComponentName name) {
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            socketService = ((SocketService.MyBinder) service).getService();

        }
    };


    Button btn_send;
    Button btn_con;
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_con = findViewById(R.id.button1);
        btn_send = findViewById(R.id.button2);
        editText = findViewById(R.id.editText);
        final Intent socketBind = new Intent(MainActivity.this, SocketService.class);
        bindService(socketBind, serviceConnection, Context.BIND_AUTO_CREATE);

        btn_con.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(getBaseContext(), SocketService.class);
                it.putExtra("cmd", "connect");
                startService(it);
                if (socketService.getState()) {
                    Toast.makeText(getApplicationContext(), "连接成功", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "连接失败", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(getBaseContext(), SocketService.class);
                it.putExtra("cmd", "send");
                it.putExtra("message", editText.getText().toString());
                startService(it);
                editText.setText("");
            }
        });


    }
}
