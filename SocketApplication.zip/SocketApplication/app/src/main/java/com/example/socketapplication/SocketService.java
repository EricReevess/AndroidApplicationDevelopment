package com.example.socketapplication;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;

import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import java.io.OutputStream;
import java.net.Socket;

public class SocketService extends Service {

    private final IBinder binder = new MyBinder();


    public class MyBinder extends Binder {
        public SocketService getService() {
            return SocketService.this;    //返回本服务
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }


    public SocketService() {
    }

    @Override
    public void onCreate() {
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                Looper.prepare();
                handler = new Handler() {

                    @Override
                    public void handleMessage(Message message) {
                        if (message.what == 1) {
                            try {
                                socket = new Socket("192.168.0.100", 12345);
                                outputStream = socket.getOutputStream();
                                isConnect = connectState(socket);
                            } catch (Exception e) {
                                Log.e("g", e.toString());
                            }
                        } else if (message.what == 2) {
                            try {
                                outputStream.write(((String) message.obj).getBytes());
                                outputStream.flush();
                            } catch (Exception e) {
                                Log.e("g", e.getMessage());
                            }
                        }
                    }
                };
                Looper.loop();
            }
        };
        thread = new Thread(runnable);
        thread.start();
    }

    @Override
    public void onDestroy() {


    }

    Socket socket;
    OutputStream outputStream;
    Thread thread;
    Handler handler;

    boolean isConnect = false;



    @SuppressLint("WrongConstant")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String cmd = intent.getStringExtra("cmd");
        if (cmd != null) {
            if (cmd.equals("connect")) {

                handler.sendEmptyMessage(1);

            } else if (cmd.equals("send")) {
                Message message = new Message();
                message.what = 2;
                message.obj = intent.getStringExtra("message");
                handler.sendMessage(message);
            }
        }


        return 0;


    }

    public boolean connectState(Socket socket){
        if (socket != null){
            return true;
        }else {
            return false;
        }
    }

    public boolean getState(){
        return isConnect;
    }
}
