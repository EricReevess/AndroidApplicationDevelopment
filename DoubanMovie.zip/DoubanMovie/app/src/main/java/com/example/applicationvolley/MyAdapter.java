package com.example.applicationvolley;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.Volley;

import java.util.List;

public class MyAdapter extends BaseAdapter {
    private List<Movie> movieList;
    private Context context;

    public MyAdapter(List<Movie> movieList, Context context) {
        this.movieList = movieList;
        this.context = context;
    }

    public int getCount(){
        return movieList.size();
    }
    public Object getItem(int i){
        return movieList.get(i);
    }
    public long getItemId(int i){
        return i;
    }
    public View getView(int i, View view, ViewGroup viewgroup){
        ViewHolder viewHolder;
        if(view == null){
            view = LayoutInflater.from(context).inflate(R.layout.child_layout,null);
            viewHolder = new ViewHolder();
            viewHolder.movieImg = view.findViewById(R.id.movieImg);
            viewHolder.movieTitle = view.findViewById(R.id.movieTitle);
            viewHolder.movieDirector = view.findViewById(R.id.movieDirector);
            viewHolder.moviePubdate = view.findViewById(R.id.moviePubdate);
            viewHolder.movieRating = view.findViewById(R.id.movieRating);
            viewHolder.movieGenres = view.findViewById(R.id.movieGenres);
            viewHolder.movieDurations = view.findViewById(R.id.movieDurations);
            view.setTag(viewHolder);
        }
        else {
            viewHolder=(ViewHolder)view.getTag();
        }
        viewHolder.movieImg.setImageResource((R.mipmap.ic_launcher));
        viewHolder.movieTitle.setText(movieList.get(i).getTitle());
        viewHolder.movieDirector.setText(movieList.get(i).getDirectors().get(0).getName());
        viewHolder.moviePubdate.setText( movieList.get(i).getPubdates());
        viewHolder.movieGenres.setText( movieList.get(i).getGenres());
        viewHolder.movieDurations.setText( movieList.get(i).getDurations());
        viewHolder.movieRating.setText( movieList.get(i).getRating().getAverage());
        loadImgCache(movieList.get(i).getImages().getMedium(), viewHolder.movieImg);
        return view;

    }

    class ViewHolder{
        ImageView movieImg;
        TextView movieTitle;
        TextView movieDirector;
        TextView moviePubdate;
        TextView movieRating;
        TextView movieGenres;
        TextView movieDurations;
    }
    private void loadImgCache(String url, ImageView imageView){
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        ImageLoader imageLoader = new ImageLoader(requestQueue, new BitmapCache());
        ImageLoader.ImageListener imageListener = ImageLoader.getImageListener(imageView,R.mipmap.ic_launcher,R.mipmap.ic_launcher);
        imageLoader.get(url,imageListener);
    }
}
