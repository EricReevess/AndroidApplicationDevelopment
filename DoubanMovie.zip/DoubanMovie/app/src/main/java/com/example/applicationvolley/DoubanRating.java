package com.example.applicationvolley;

public class DoubanRating {
    int max;
    float average;
    String star;
    int min;

    public DoubanRating() {
    }

    public DoubanRating(int max, float average, String star, int min) {
        this.max = max;
        this.average = average;
        this.star = star;
        this.min = min;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public String getAverage() {
        return average + "";
    }

    public void setAverage(float average) {
        this.average = average;
    }

    public String getStar() {
        return star;
    }

    public void setStar(String star) {
        this.star = star;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }
}
