package com.example.applicationvolley;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class DoubanDirector {

    String name;

    public DoubanDirector() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
