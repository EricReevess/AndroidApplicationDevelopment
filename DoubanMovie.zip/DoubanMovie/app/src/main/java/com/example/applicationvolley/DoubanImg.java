package com.example.applicationvolley;

public class DoubanImg {
    String small;
    String large;
    String medium;

    public DoubanImg() {
    }

    public DoubanImg(String small, String large, String medium) {
        this.small = small;
        this.large = large;
        this.medium = medium;
    }

    public String getSmall() {
        return small;
    }

    public void setSmall(String small) {
        this.small = small;
    }

    public String getLarge() {
        return large;
    }

    public void setLarge(String large) {
        this.large = large;
    }

    public String getMedium() {
        return medium;
    }

    public void setMedium(String medium) {
        this.medium = medium;
    }
}
