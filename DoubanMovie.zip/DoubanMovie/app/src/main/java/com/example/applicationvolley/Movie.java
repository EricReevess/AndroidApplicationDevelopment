package com.example.applicationvolley;


import android.widget.ListView;

import java.util.List;

public class Movie {
    private String title;
    private List pubdates;
    private List genres;
    private List durations;
    private DoubanImg images;
    private DoubanRating rating;
    private List<DoubanDirector> directors;

    public Movie() {
    }

    public Movie(String title, List pubdates, List genres, List durations, DoubanImg images, DoubanRating rating, List<DoubanDirector> directors) {
        this.title = title;
        this.pubdates = pubdates;
        this.genres = genres;
        this.durations = durations;
        this.images = images;
        this.rating = rating;
        this.directors = directors;
    }

    public String getDurations() {
        String string = durations.toString();
        return string.substring(1,string.length()-1) ;
    }

    public void setDurations(List durations) {
        this.durations = durations;
    }

    public String getGenres() {
        String string = genres.toString();
        return string.substring(1,string.length()-1) ;
    }

    public void setGenres(List genres) {
        this.genres = genres;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPubdates() {
        return pubdates.get(pubdates.size()-1).toString();
    }

    public void setPubdates(List pubdates) {
        this.pubdates = pubdates;
    }

    public DoubanImg getImages() {
        return images;
    }

    public void setImages(DoubanImg images) {
        this.images = images;
    }

    public DoubanRating getRating() {
        return rating;
    }

    public void setRating(DoubanRating rating) {
        this.rating = rating;
    }

    public List<DoubanDirector> getDirectors() {
        return directors;
    }

    public void setDirectors(List<DoubanDirector> directors) {
        this.directors = directors;
    }
}